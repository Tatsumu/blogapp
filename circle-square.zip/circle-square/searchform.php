<form role="search" method="get" id="searchform" action="/search" >
    <input type="text" value="" name="s" class="s" />
    <input type="submit" class="searchsubmit" value="検索" />
</form>
