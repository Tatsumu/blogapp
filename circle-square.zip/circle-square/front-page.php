<?php get_header(); ?>


    <div class="main_parent">
        <div class="main clearfix">

        <?php get_sidebar(); ?>
        <div class="random">
            <ul data-show="6" id="random" class="random_grid">
                <li class="random_grid_item">
                    <div class="random_icon"><img src="<?php echo get_template_directory_uri(); ?>/img/sample_icon.jpeg" alt=""></div>
                    <div class="random_name">About</div>
                    <div class="random_description">バスケも遊びも全力！<br>SFC No.1バスケサークル</div>
                </li>
                <li class="random_grid_item">
                    <div class="random_icon"><img src="<?php echo get_template_directory_uri(); ?>/img/sample_icon.jpeg" alt=""></div>
                    <div class="random_name">About</div>
                    <div class="random_description">バスケも遊びも全力！<br>SFC No.2バスケサークル</div>
                </li>
                <li class="random_grid_item">
                    <div class="random_icon"><img src="<?php echo get_template_directory_uri(); ?>/img/sample_icon.jpeg" alt=""></div>
                    <div class="random_name">About</div>
                    <div class="random_description">バスケも遊びも全力！<br>SFC No.3バスケサークル</div>
                </li>
                <li class="random_grid_item">
                    <div class="random_icon"><img src="<?php echo get_template_directory_uri(); ?>/img/sample_icon.jpeg" alt=""></div>
                    <div class="random_name">About</div>
                    <div class="random_description">バスケも遊びも全力！<br>SFC No.4バスケサークル</div>
                </li>
                <li class="random_grid_item">
                    <div class="random_icon"><img src="<?php echo get_template_directory_uri(); ?>/img/sample_icon.jpeg" alt=""></div>
                    <div class="random_name">About</div>
                    <div class="random_description">バスケも遊びも全力！<br>SFC No.5バスケサークル</div>
                </li>
                <li class="random_grid_item">
                    <div class="random_icon"><img src="<?php echo get_template_directory_uri(); ?>/img/sample_icon.jpeg" alt=""></div>
                    <div class="random_name">About</div>
                    <div class="random_description">バスケも遊びも全力！<br>SFC No.6バスケサークル</div>
                </li>
                <li class="random_grid_item">
                    <div class="random_icon"><img src="<?php echo get_template_directory_uri(); ?>/img/sample_icon.jpeg" alt=""></div>
                    <div class="random_name">About</div>
                    <div class="random_description">バスケも遊びも全力！<br>SFC No.7バスケサークル</div>
                </li>
                <li class="random_grid_item">
                    <div class="random_icon"><img src="<?php echo get_template_directory_uri(); ?>/img/sample_icon.jpeg" alt=""></div>
                    <div class="random_name">About</div>
                    <div class="random_description">バスケも遊びも全力！<br>SFC No.8バスケサークル</div>
                </li>
                <li class="random_grid_item">
                    <div class="random_icon"><img src="<?php echo get_template_directory_uri(); ?>/img/sample_icon.jpeg" alt=""></div>
                    <div class="random_name">About</div>
                    <div class="random_description">バスケも遊びも全力！<br>SFC No.9バスケサークル</div>
                </li>
            </ul>
        </div>
    </div>
    </div>



<?php get_footer(); ?>
